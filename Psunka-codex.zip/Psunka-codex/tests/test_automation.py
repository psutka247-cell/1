from automation import sanitize_transcript_text


def test_sanitize_removes_category_digit_prefix():
    assert sanitize_transcript_text("1это только там") == "это только там"


def test_sanitize_removes_gui_prefixes():
    assert sanitize_transcript_text("[15:39:51] [Category: 1] это только там") == "это только там"
